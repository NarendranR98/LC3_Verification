#!/bin/bash
pwd
make clean
rm -rf *.ucdb
python3 $UVMF_HOME/scripts/uvmf_bcr.py questa -s run seed:123456 verbosity:UVM_LOW
make merge_coverage
make view_coverage
